"""Train production-compatible models from a CSV whose columns match app.engine.FEATURES plus targets."""
import argparse,joblib,pandas as pd
from pathlib import Path
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge,LogisticRegression
from sklearn.metrics import mean_absolute_error,mean_squared_error,brier_score_loss,log_loss
from app.engine import FEATURES
def main():
 p=argparse.ArgumentParser();p.add_argument("--csv",required=True);p.add_argument("--out",default="data/cfb_model.joblib");p.add_argument("--holdout-season",type=int,required=True);a=p.parse_args()
 d=pd.read_csv(a.csv);tr=d[d.season<a.holdout_season];te=d[d.season==a.holdout_season]
 if tr.empty or te.empty:raise ValueError("Need training seasons before holdout season.")
 margin=Pipeline([("s",StandardScaler()),("m",Ridge(alpha=8))]);total=Pipeline([("s",StandardScaler()),("m",Ridge(alpha=8))]);win=Pipeline([("s",StandardScaler()),("m",LogisticRegression(C=.3,max_iter=3000))])
 margin.fit(tr[FEATURES],tr.target_margin);total.fit(tr[FEATURES],tr.target_total);win.fit(tr[FEATURES],tr.home_win)
 pm=margin.predict(te[FEATURES]);pt=total.predict(te[FEATURES]);pp=win.predict_proba(te[FEATURES])[:,1]
 metrics={"holdout":a.holdout_season,"games":len(te),"margin_mae":mean_absolute_error(te.target_margin,pm),"margin_rmse":mean_squared_error(te.target_margin,pm)**.5,"total_mae":mean_absolute_error(te.target_total,pt),"total_rmse":mean_squared_error(te.target_total,pt)**.5,"brier":brier_score_loss(te.home_win,pp),"log_loss":log_loss(te.home_win,pp)}
 Path(a.out).parent.mkdir(parents=True,exist_ok=True);joblib.dump({"margin":margin,"total":total,"win":win,"metrics":metrics,"features":FEATURES},a.out);print(metrics)
if __name__=="__main__":main()
