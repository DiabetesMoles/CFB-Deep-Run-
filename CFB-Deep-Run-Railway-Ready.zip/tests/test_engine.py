from app.engine import estimate,FEATURES
def test_engine():
 x={k:0 for k in FEATURES};m,t,p,s=estimate(x)
 assert 0<p<1 and 30<t<90
